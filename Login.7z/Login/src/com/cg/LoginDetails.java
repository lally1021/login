package com.cg;

import java.util.Scanner;
public class LoginDetails {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
	        System.out.println("enter your first name");
	        String firstName=scanner.nextLine();
	        System.out.println("enter your last name");
	        String lastName=scanner.nextLine();
	        
	        System.out.println("enter Id proof details");
	        String id=scanner.nextLine();
	        System.out.println("enter dob in DD/MM/YYYY");
	        String dob=scanner.nextLine();
	    System.out.println(dob);
	        System.out.println("enter mobile number");
	        String mobile=scanner.next();
		
		String[] fn = firstName.split("");
		String user1=fn[0]+fn[1];
		 String[] ln = lastName.split("");
		 String user2=ln[ln.length-1]+ln[ln.length]; 
		 String user=user1.concat(user2);
		 StringBuilder sb=new StringBuilder(user);
		 StringBuilder username=sb.reverse();
		String userName=username.toString();
		int rand_user = 0;
		String s = Integer.toString(rand_user); 
		String result=userName.concat(s);
		System.out.println("userName is:"+result);
	 
	
			String[] fn1 = firstName.split("");
			String str1 = fn1[fn1.length];
			 String[] ln1= lastName.split("");
		 String str2 = ln1[0];
		 String[] ph = mobile.split("");
		 for (int i = 0; i < ph.length; i++) 
	     {
			ph[i] = scanner.next();
	         if(i % 2 != 0)
	             System.out.print(ph[i]+" ");
	     }String pas = str1.concat(str2.concat(" "));
		 
	     String dateOfBirth=dob;
	     String month="04";
	     String date="14";
		 String year="1995";
		 String[] yr = "1995".split("");
		 String[] mon = "04".split("");
		 String[] dt = "14".split("");
	     for(int i=0; i<yr.length; i++) {
	    	String k="0";
	    	 k=k+yr[i];
	    	String m=mon[mon.length];
	    	String d=dt[0];
	    	String str3=k+m+d;
		String res=pas.concat(str3);
	  
		 String Id = id;
		 Id=Id.toLowerCase();
		 for(int i1 = 0; i1 < Id.length(); ++i1) {
			 char ch = Id.charAt(i1);
	         if(ch == 'a' || ch == 'e' || ch == 'i'|| ch == 'o' || ch == 'u'||ch >= '0' && ch <= '9') {
	        	 if(ch%2==0) 
	            System.out.println(ch);
	          
	            String password=res+ch;
	         System.out.println("password;"+password);
	        	 }
	         }
	    }
		
		}
	
}
