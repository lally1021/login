package com.cg;

import java.util.Date;
import java.util.Scanner;

public class Login {


	public static void main(String[] args) {
		String u1 = null;
		String u2 = null;
		long array[] = new long[10];
		int array1[] = new int[10];
		String userName = null;
		String p1 = null;
		Scanner scanner = new Scanner(System.in);
		System.out.println("enter your first name");
		String fname = scanner.nextLine();
		System.out.println("enter your last name");
		String lname = scanner.nextLine();

		System.out.println("enter Id proof details");

		String id = scanner.nextLine();
		System.out.println("enter dob in DD/MM/YYYY");
		String dob = scanner.nextLine();
		System.out.println(dob);
		System.out.println("enter mobile number");
		long mob = scanner.nextLong();

		int x = 0;
		int i = 0;
		int z = 0;
		String str = "";
		Date date = new Date();
		String str1 = "";
		StringBuffer number = new StringBuffer();

		for (int j = 0; j < id.length(); j++) {

			if (id.charAt(j) == 'a' || id.charAt(j) == 'e' || id.charAt(j) == 'i' || id.charAt(j) == 'o'
					|| id.charAt(j) == 'u' || id.charAt(j) == 'A' || id.charAt(j) == 'E' || id.charAt(j) == 'I'
					|| id.charAt(j) == 'O' || id.charAt(j) == 'U') {
				str1 += id.charAt(j);
			}

		}

		for (z = 0; z < id.length(); z++)

		{

			if (Character.isDigit(id.charAt(z)))

				number.append(id.charAt(z));
		}
		String s = "";

		String g = number.toString();
		int q = Integer.parseInt(g);
		while (q > 0) {
			int remainder = q % 10;
			if (remainder % 2 == 0) {

				s += Integer.toString(remainder);
			}
			q = q / 10;
		}
		StringBuffer numberString = new StringBuffer(s);
		numberString.reverse();

		if (fname.length() > 1) {
			str = fname.substring(fname.length() - 1);

		}

		str += lname.substring(0, 1);

		while (i < 10) {
			int rem = (int) (mob % 10);
			array[i] = rem;
			mob = mob / 10;
			i++;

		}

		for (i = 9; i > 0; i -= 2) {
			str += array[i];
		}

		if (fname.length() > 2) {
			u1 = fname.substring(0, 2);
		} else {
			System.out.println("enter first name of length 2");
		}
		if (lname.length() > 2) {
			u2 = lname.substring(lname.length() - 2);
		}
		userName = u1.concat(u2);

		StringBuffer reverseUserName = new StringBuffer(userName);
		reverseUserName.reverse();
		String finalUsser = reverseUserName.toString();
		int ran = (int) (Math.random() * 1000);
		String numb = Integer.toString(ran);
		int sum = 0;
		if (dob.length() > 4) {
			String year = dob.substring(dob.length() - 4);
			System.out.println(year);
			int year1 = Integer.parseInt(year);
			while (year1 > 0) {
				int rem = year1 % 10;
				sum = sum + rem;
				year1 = year1 / 10;

			}
		}
		String day = dob.substring(0, 1);
		System.out.println(day);

		String month = dob.substring(4, 5);
		System.out.println(month);
		int day1 = Integer.parseInt(day);
		int month1 = Integer.parseInt(month);
		int sum2 = day1 + month1 + sum;
		System.out.println(sum2);
		int res = 0, count = 0, rem1, temp;
		boolean temp1 = true;
		while (temp1) {
			res = 0;
			while (sum2 > 0) {
				rem1 = sum2 % 10;
				res = res + rem1;
				sum2 = sum2 / 10;
			}
			temp = res;
			while (temp > 0) {

				count++;
				temp /= 10;
			}
			if (count > 1) {
				sum2 = res;
				count = 0;
				temp1 = true;
			} else {
				temp1 = false;

			}

		}

		System.out.println("Welcome " + fname + " your login credentials are \n Username: " + finalUsser + numb
				+ " \n Password is " + str + res + str1 + numberString + "\n generated at " + date
				+ "\n Please login now to change your password");
	}
}


